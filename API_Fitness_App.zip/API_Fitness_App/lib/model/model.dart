class ExcerciesModel {
  String? id, title, thumbnail, gif, seconds;

  ExcerciesModel({this.gif, this.thumbnail, this.id, this.seconds, this.title});
}
